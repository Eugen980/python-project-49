EVEN_INSTR = 'Answer "yes" if the number is even, otherwise answer "no".'
CALC_INSTR = 'What is the result of the expression?'
title_calc = 'brain-calc'
title_even = 'brain-even'
